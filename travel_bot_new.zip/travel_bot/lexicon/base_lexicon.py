CURRENCY_DICT: dict[str, str] = {
    "RUB": "Рубль RUB",
    "USD": "Доллар USD",
    "EUR": "Евро EUR",
    "AED": "Дирхам AED",
    "GBP": "Фунт GBP",
    "CNY": "Юань CNY",
    "TRY": "Лира TRY",
    "EGP": "Фунт EGP",
    "INR": "Рупия INR",
}
