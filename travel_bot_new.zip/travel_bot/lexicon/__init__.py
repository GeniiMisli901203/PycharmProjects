from .base_lexicon import *
from .lexicon_ru import *
